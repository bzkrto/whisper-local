@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Mikrofon ve arka plan ogrenmesi acilmadan ElevenLabs sesi deneniyor.
".venv\Scripts\python.exe" "whisper_ses_v12.py" --test-voice --tts elevenlabs --allow-cloud
echo.
pause
