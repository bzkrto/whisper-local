"""One entry point: verify the integrated package, then launch the existing environment."""
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main(argv=None):
    argv = list(argv or [])
    if any(arg not in ("--check-only", "--mobile", "--elevenlabs") for arg in argv):
        print("Kullanım: whisper_bootstrap.py [--check-only] [--mobile] [--elevenlabs]")
        return 2
    os.chdir(ROOT)
    try:
        if (ROOT/'.whisper-update.lock').exists():
            raise RuntimeError('Kod güncellemesi devam ediyor; işlem tamamlandıktan sonra yeniden başlatın.')
        manifest = json.loads((ROOT / 'WHISPER_SURUM.json').read_text(encoding='utf-8'))
        for name, expected in manifest['files'].items():
            path = ROOT / name
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                raise RuntimeError('Güncelleme eksik veya dosyalar farklı: '+name+'. ZIP içeriğinin tamamını aynı klasöre çıkarın.')
    except (OSError, ValueError, RuntimeError) as exc:
        print('Başlatma durduruldu:', exc)
        return 1
    print('WHISPER '+manifest['version']+' · Paket bütünlüğü doğrulandı.')
    if '--check-only' in argv:
        # Read-only: no package installation, model download, microphone or app launch.
        names = ['numpy', 'requests', 'sounddevice', 'speech_recognition', 'faster_whisper',
                 'edge_tts', 'docx', 'reportlab', 'pypdf', 'psutil']
        if sys.platform == 'win32':
            names += ['pycaw', 'comtypes']
        missing = [name for name in names if importlib.util.find_spec(name) is None]
        print('Python:', sys.version.split()[0], '| Platform:', sys.platform)
        print('Eksik modüller:', ', '.join(missing) if missing else 'yok')
        print('Yalnız dosya bütünlüğü ve modül varlığı kontrol edildi. '
              'Windows güvenliği, GPU, model ve mikrofon çalışması doğrulanmadı.')
        return 1 if missing else 0
    # Prepare the selected local voice package; preserve existing GPU/model setup.
    if sys.platform == 'win32':
        missing = [name for name in ('pycaw', 'comtypes') if importlib.util.find_spec(name) is None]
        if missing:
            print('Eksik ses paketleri kuruluyor:', ', '.join(missing))
            result = subprocess.run([sys.executable, '-m', 'pip', 'install', *missing])
            if result.returncode:
                print('Paket kurulamadı; Whisper başlatılmadı. Yukarıdaki kurulum hatasını kontrol edin.')
                return result.returncode
    if sys.platform == 'win32' and '--elevenlabs' in argv:
        from whisper.voice.elevenlabs_tts import load_key
        if not load_key():
            print('Seçtiğiniz ElevenLabs sesi için anahtar ayarı açılıyor.')
            setup_result=subprocess.call([sys.executable,'-m','whisper.voice.elevenlabs_tts'])
            if setup_result or not load_key():
                print('ElevenLabs anahtarı kaydedilmedi; WHISPER_ELEVENLABS_AYAR.cmd ile ayarlayabilirsiniz.')
                return 1
    if sys.platform == 'win32' and '--elevenlabs' not in argv:
        from whisper.voice.reference_setup import ready
        if not ready():
            print('İndirdiğiniz MP3 kaydını seçin. İlk kurulumda yerel ses ortamı ve yaklaşık 1,9 GB model hazırlanır.')
            result=subprocess.call([sys.executable,'-m','whisper.voice.reference_setup','--setup'])
            if result or not ready():
                print('Referans ses kurulumu tamamlanmadı; WHISPER_SES_KAYDI.cmd ile devam edebilirsiniz.')
                return 1
    command = [sys.executable, str(ROOT/'whisper_ses_v12.py'), '--gui', '--model', 'qwen3:8b',
               '--tts', ('elevenlabs' if '--elevenlabs' in argv else 'reference'), '--allow-cloud',
               '--whisper-device', 'auto', '--whisper-beam', '5', '--silence-seconds', '0.8',
               '--conversation-timeout', '20',
               '--enable-tools', '--enable-screen', '--web',
               '--role-model', 'chat=qwen3:8b', '--role-model', 'code=qwen2.5-coder:7b',
               '--role-model', 'vision=qwen3-vl:4b']
    if '--mobile' in argv:
        command.append('--server')
    return subprocess.call(command)

if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
