# Whisper V32 — sohbet ve test edilen otomatik kod geliştirme

Bu sürüm yüklenen V31 dosyaları üzerine geliştirilmiştir. Whisper_OS_Mimari_Tasarim.pdf bir vizyon belgesidir; aşağıdaki tablo uygulanan parçaları ve gelecekte yapılacak işleri ayırır.

| Mimari parçası | V32'deki karşılığı |
| --- | --- |
| Core Brain / doğal sohbet | Aynı komut işleyicisi ses ve yazıyı karşılar; son sekiz konuşma turu bağlama girer. GUI'de Sohbet ve İşlem günlüğü ayrı sekmelerdir. |
| AI Router | chat, code, reason, vision ve fast rolleri; kurulu Ollama modelleri ve ayrı rol sunucuları. PDF'deki DeepSeek/Gemma adları zorunlu değildir. |
| Kalıcı hafıza | Kullanıcı beyanları, geçmiş konuşma, belge/kaynak kayıtları, deneyimler ve kaynaklı bilgi kartları. Gerçek anlamsal embedding veya bilgi grafiği bu güncellemede eklenmedi. |
| Learning / kod geliştirme | Kaynaklı gelişim taslağı veya açık kullanıcı hedefi -> ayrı kod taslağı -> Docker testleri -> yedekli kaynak ve sürüm bildirimi güncellemesi. |
| Ses / Türkçe | Microsoft EmelNeural, normal hız; yerel Whisper; kalıcı kullanıcı terim sözlüğü; bağlamdaki tek kelimelik yanıtlar korunur. |
| Computer Control | Mevcut izinli araçlar, uygulama envanteri, ekran ve dosya işlemleri korunur. |
| Rapor / sunum / video | Mevcut Word/PDF/PowerPoint ve senaryo akışı korunur. Otomatik video render eklenmedi. |
| Security / Behavior / Order | Mevcut araç doğrulama ve hatırlatmalar korunur. Antivirüs, hesap güvenliği denetimi, alışkanlık çıkarımı veya satın alma ajanı eklenmedi. |

## Bilgisayarda kurulum

1. Whisper'ı kapatın. Mevcut whisper astra klasörünün yedeğini alın.
2. WHISPER_V32_GUNCELLEME.zip içeriğini mevcut proje klasörüne çıkarın; aynı adlı kod dosyalarını güncelleyin.
3. Paket kişisel veritabanını, mikrofon profilini, ses referanslarını, .venv ortamını veya modelleri içermez; bunları koruyun.
4. Ollama'yı açın. Mevcut qwen3:8b sohbet ve qwen2.5-coder:7b kod modeli kullanılır. Görsel model yalnız ekran isteğinde gereklidir.
5. Kod geliştirmede kullanılacak test imajını WHISPER_TEST_ORTAMI.cmd ile hazırlayın. Docker Desktop açık olmalıdır. İmaj hazırlanmamışsa kod güncellemesi uygulanmaz; durum günlüğünde görünür.
6. WHISPER_KONTROL.cmd ile paket kontrolünü, WHISPER_BASLAT.cmd ile uygulamayı açın.

## Karşılıklı konuşma

İlk komutta “Hey Whisper” deyin. Yanıt tamamlandıktan sonraki 20 saniye boyunca tekrar seslenmeden konuşabilirsiniz. Modelin yanıt üretme ve seslendirme süresi bu pencereyi tüketmez. “Sohbeti bitir”, “Dinlemeyi bitir” veya “Şimdilik bu kadar” bu pencereyi kapatır. “Dur / sus” yanıtı keser; “çıkış” uygulamayı kapatır.

İsterseniz CLI'de --single-turn ile her komut için tekrar seslenme davranışını seçebilirsiniz. --conversation-timeout 5–120 saniye aralığında ayarlanabilir. Mikrofon düğmesi ses girişini kapatır.

Genel bilgi soruları, “nedir / kaç” sözcükleri yüzünden internet kapalıyken engellenmez. Güncel fiyat/haber/hava gibi gerçekten dış kaynağa ihtiyaç duyan sorularda mevcut doğrulama akışı korunur. Kısa isim/uygulama yanıtları bir açıklama sorusuna cevap olduğunda rastgele kelime sayılıp atılmaz.

## Ses ve kelimeler

Windows başlatıcısı artık Microsoft EmelNeural ve normal hız kullanır. Önceki başlatıcıdaki AhmetNeural de Microsoft hizmetiydi; Google TTS kullanılmıyordu. İlk V32 açılışı yeni tercihi kaydeder; sonraki kullanıcı seçimleri korunur. “Ahmet sesini kullan”, “Emel sesini kullan”, “Normal hızda konuş” gibi komutlar kullanılabilir.

“Kelime öğret: Bergen” veya “Kelime öğret: bütçe raporu” terimi yerel ses sözlüğüne kaydeder. “Ses sözlüğü” kayıtları gösterir. Bu terimler sonraki Whisper tanımalarında ipucu olur; duyulmayan bir cümle yerine komut yazılmaz ve model ağırlıkları eğitilmez.

Edge hizmeti erişilemezse yalnız kurulu Türkçe Windows sesi yedek olarak kullanılır. Türkçe yerel ses yoksa İngilizce bir sesle yanlış telaffuz edilmez; metin yanıtı korunur. Windows oynatma ve fiziksel mikrofon/GPU doğruluğu bilgisayarınızda ayrıca kontrol edilmelidir.

## Kendi kodunu geliştirme

- “Kendini geliştir: Türkçe kısa yanıtların önceki soruya bağlanmasını iyileştir” açık bir geliştirme hedefi ekler.
- “Gelişim durumu” veya “Otomatik gelişim durumu” aşamaları gösterir.
- “Otomatik gelişimi durdur / başlat” kalıcı anahtarı değiştirir.
- Kaynaklı bilgi kartlarından üretilen gelişim hedefleri de otomatik sıraya alınır.

Program açıkken zamanlayıcı boşta, tek bir hedef üzerinde çalışır. Her hedef en fazla üç kod denemesi yapar; sonraki denemeye önceki test hatası veri olarak eklenir. İşlem aralığı en az on dakikadır. Öndeki kullanıcı komutu için ayrılan kilit ve iptal denetimleri korunur.

Her taslak en fazla iki küçük mevcut Python modülünü değiştirir; güncelleyici, izin kontrolleri, testler ve bağımlılıklar model tarafından değiştirilmez. Kod, ağ ve kişisel veriler bulunmayan, kaynak kopyası salt okunur Docker ortamında test edilir. Sıfır test çalışması başarı kabul edilmez. Başarısız veya iptal edilen taslak canlı koda yazılmaz. Test edilen içerik veya canlı kaynak arada değişirse uygulama durdurulur.

Başarılı güncellemede değişen dosyalar ve WHISPER_SURUM.json yedeklenir; dosyalar geçici dosya üzerinden değiştirilir, sürüm bildirimi en son yazılır. Normal yazma hatasında değişen dosyalar geri alınır. Güncelleme kilidi sırasında ikinci güncelleme ve yeni bootstrap açılışı engellenir. Güncellenen kod bir sonraki uygulama açılışında etkinleşir; mevcut Python nesneleri kendiliğinden yeniden yüklenmiş sayılmaz.

Yedekler veritabanı klasöründeki iyilestirme_taslaklari/<taslak>/backup dizinindedir. Süreç veya bilgisayar güncellemenin ortasında zorla kapanırsa kilit kalabilir: işlem artık çalışmıyorsa bu dizindeki yedekleri proje klasörüne geri koyup .whisper-update.lock dosyasını kaldırın. Başlatıcı bütünlük bozukken çalışmayı reddeder.

Bu akış kodu değiştirebilir; her değişikliğin yararlı olduğunu veya genel zekâyı artırdığını garanti etmez. Test kapsamı ve seçilen kod modelinin kalitesi belirleyicidir. Buluttaki küçük kod modeli Türkçe harf düzeltmesinde başarısız taslaklar üretti; testler bunların uygulanmasını engelledi. Model ağırlıkları eğitilmez.

## Bulut doğrulaması

Tüm otomatik testler son doğrulamada ayrıca raporlanır. Gerçek Microsoft Emel sesiyle MP3 üretildi; bu bilinen kısa örnek, gerçek CPU faster-whisper ile sıfır kelime hatasıyla tanındı. Bu ölçüm mikrofonunuzun doğruluk oranı değildir.

Bulut geliştirme için ayrı Qwen sohbet ve Qwen2.5-Coder CPU sunucuları, yerel faster-whisper-small ve izole Docker test imajı hazırlandı. Windows'taki qwen3:8b/qwen2.5-coder:7b modellerinin kalitesi ve GPU performansı bu kontrolün sonucu olarak gösterilmez.

## V32.1 tok erkek ses profili

Kullanıcı isteğiyle varsayılan ses Türkçe destekleyen Microsoft BrianMultilingualNeural erkek sesi olarak değiştirildi. Hız ve ton normaldir (+0%, +0Hz); sesin kendi doğal erkek tınısı kullanılır. İlk V32.1 açılışı bu profili kaydeder, sonraki kullanıcı tercihleri korunur. “Brian sesini kullan” veya “Erkek sesini kullan” bu sesi seçer. “Ahmet sesini kullan” ve “Emel sesini kullan” önceki seçeneklere döner. CLI --voice, --rate ve --pitch açıkça verilirse kayıtlı ayarı geçersiz kılar; ton tercihi de artık kalıcıdır.

Bu güncelleme aynı Microsoft Edge ses hizmetini kullanır; ücretli sağlayıcı veya ses klonlama eklenmemiştir. BrianMultilingualNeural adındaki en-US, ses kimliğinin adıdır; model Türkçe konuşabilir. Türkçe örnek çevrimiçi hizmetle gerçekten üretildi. Ahmet için denenen negatif hız/ton ayarlarında bu ortamda ses alınamadığından bunlar varsayılan yapılmadı. Tokluk ve aksan beğenisi kullanıcı tarafından örnek dinlenerek değerlendirilmelidir.

## V32.2 öğrenme durumu ve arama düzeltmesi

“Bugün neler öğrendin?” artık kısa bir günlük durum verir: bugün okunan kaynaklar ve bugün işlenen belge bölümleri ayrı sayılır. Eski kaynaktan bugün üretilen bilgi kartları günlük işleme sayısına dahildir. Bekleyen ve hatalı bölümler ayrı gösterilir; en fazla iki kısa kaynak özeti verilir. “Öğrenme günlüğü” ayrıntılı raporu korur. Biriken bölümler yüzünden yeni belge okuma bekletiliyorsa bunun nedeni açıkça yazılır.

Ekranda görülen “Bugün neler ağlandı?” ifadesi sessizce düzeltilmez: öğrenme sorusu olup olmadığı sorulur; “Evet” yanıtı günlük özeti açar. Başka bir komut bu bekleyen soruyu kapatır. Bu değişiklik akustik modeli eğitmez. Tanımaya öğrenme/araştırma kelime ipuçları eklendi.

Web araması Bing ve DuckDuckGo sağlayıcılarını sınırlı denemelerle kullanır. Bir sağlayıcı hata verirse diğeri denenir. Cloudflare bağlantı denemesi aramanın ön koşulu olmaktan çıkarıldı; Cloudflare erişilemese bile arama denenir. Her iki sağlayıcı da sonuç vermezse doğrulanmış bilgi uydurulmaz. Sağlayıcı hataları durum günlüğünde ayrılır. Ağ engeli, hizmet kesintisi veya Windows bağlantı sorunu bu değişiklikle otomatik olarak giderilmiş sayılmaz.

## V32.3: tekrarlayan hataların nedenleri

Önceki düzeltme yalnız bir yanlış tanınan cümleyi ele alıyordu. Bu sürüm öğrenme sorularını merkezi niyet sınıflandırıcısında tanır: “Bugün neler öğrendin”, “Bugün bana ne öğrendiğini anlat”, “Bugünkü öğrenmelerini özetle” ve benzeri iç raporlar web aramasına gitmez. “Bugün neler öğrendim” gibi kişi eki belirsizliği için onay istenir; “Evet” asistanın özetini açar. “Ben bugün ne öğrendim” sessizce asistanın öğrenmesine dönüştürülmez. Açık internet/haber/araştırma istekleri dış kaynak akışını korur.

Başlatıcı varsayılanı artık **yerel Piper Türkçe sesi**. İlk Windows açılışında eksikse piper-tts 1.8.0 kurulur, sabit kaynak sürümünden 63 MB Türkçe model ve yapılandırması indirilir; SHA256 ve boyut doğrulanır. Sonraki açılışlarda doğrulanmış yerel dosyalar kullanılır; ses üretimi çevrimiçi servise veya Windows Türkçe ses paketine bağlı değildir. Bu seçim Brian ile aynı tınıyı vaat etmez: farklı bir yerel sentetik sestir. Örnek dinlenerek değerlendirilmelidir. Piper sesi için lisans ve kaynak bilgisi whisper/voice/PIPER_MODEL_LICENSE.md dosyasındadır.

Önceki çevrimiçi Brian profili korunur ancak varsayılan başlatıcı onu kullanmaz. İsteğe bağlı --tts edge --allow-cloud çevrimiçi hizmeti seçer; hizmetin 403 yanıtını kodla ortadan kaldırma garantisi verilmez. Yerel ses modunda Brian/Emel değiştirme komutları başarılı olmuş gibi gösterilmez. Konuşmayı durdurma yerel sesin sonraki oynatma bloğunda uygulanır; geçici ses dosyası temizlenir.

Yapılandırılmış model çağrısında şemanın metin uzunlukları artık modele açıkça iletilir. Hata bildirimi alan yolunu, gelen uzunluğu ve beklenen aralığı söyler; bir düzeltme denemesinde geçersiz önceki çıktı veri olarak sunulur. Kabul testinde “0 -> 1” gibi kısa ve anlamlı değerler geçerlidir; boş değer, yanlış tür, eksik alan ve üst sınır ihlali hâlâ reddedilir. Aynı kaynak için gelişim taslağı üç analiz turunda üretilemezse kalıcı olarak durdurulur; modelin hatalı çıktısı canlı koda uygulanmaz. Bu, her yerel modelin mutlaka geçerli veya yararlı taslak üreteceğini garanti etmez.

Kurulum: Whisper’ı kapatın, klasörünü yedekleyin, V32.3 ZIP’in tamamını mevcut klasörün üzerine çıkarın ve WHISPER_BASLAT.cmd dosyasını açın. İlk yerel ses kurulumu için internet gerekir; model ZIP içinde değildir. Fiziksel mikrofon, Windows ses çıkışı ve GPU uygulaması bulut testleriyle doğrulanamaz.

V32.3 doğrulama: 435 otomatik test geçti; kaynak paketi kontrolü başarılı. Yerel Piper ile gerçek WAV üretildi; indirilmiş modelde ağ isteği engellendiğinde yeniden sentez başarılı oldu. Örnek gerçek Türkçe Whisper ile tanındı; ürün adında bir tanıma farkı olduğundan sıfır kelime hatası iddiası yoktur. Gerçek küçük yerel kod modeliyle şemaya uygun gelişim taslağı alındı; bu denemede canlı kod güncellenmedi. Fiziksel Windows ses çıkışı hâlâ doğrulanmadı.

## V32.4 seçilen ElevenLabs sesi

Varsayılan Windows başlatıcı artık kullanıcı tarafından seçilen ElevenLabs sesi lSX8MEhRyl5ZEeI3jfgm ile çalışır. Resmi /v1/text-to-speech API’si, eleven_multilingual_v2 modeli, Türkçe dil seçimi ve 24 kHz PCM çıktısı kullanılır. Seslendirilmek üzere hazırlanan metin ElevenLabs’e gönderilir; kullanım hesabın kotasından düşer. API anahtarı sohbet mesajına, kaynak koda veya kişisel hafıza veritabanına yazılmaz. Windows’ta LOCALAPPDATA/WhisperAstra/elevenlabs.dpapi dosyasında mevcut kullanıcı için DPAPI ile şifrelenir. Başka bilgisayarda yeniden ayarlanması gerekir. Linux/cloud için WHISPER_ELEVENLABS_API_KEY ortam değişkeni kullanılır.

İlk açılışta anahtar yoksa gizli giriş penceresi açılır. ElevenLabs hesabınızın Developers / API Keys bölümünden Text to Speech yetkili anahtar oluşturup bu pencereye yapıştırın. Anahtarı bu sohbete göndermeyin. İptal ederseniz uygulama farklı bir sesi kullanarak başlamaz. WHISPER_ELEVENLABS_AYAR.cmd anahtarı sonradan değiştirebilir. Seçilen ses hesabınızda erişilebilir olmalıdır; gerekirse https://elevenlabs.io/voices/lSX8MEhRyl5ZEeI3jfgm bağlantısından Voice Library’ye ekleyin. Hesap planı ve ses erişim koşulları ElevenLabs tarafından belirlenir.

Başarılı ses aynı çalışma oturumunda sınırlı önbelleğe alınır; aynı metni yeniden çalmak için ikinci ücretli istek yapılmaz. Başarısız/yarım istek otomatik tekrarlanmaz; kimlik, kota veya hizmet hatasında kısa bekleme uygulanır. Başka bir sese otomatik geçilmez, metin yanıtı ekranda kalır. Ses kesilince indirme/oynatma iptal edilir; geçici WAV silinir. Piper ve Microsoft seçenekleri CLI’de ayrı seçim olarak korunur ancak varsayılan Windows başlatıcı bunları kullanmaz.

Geliştirici doğrulaması seçilen ses kimliği, Türkçe/model parametreleri, anahtar gizliliği, ses önbelleği, iptal, kota hatası ve ilk kurulum iptali akışlarını kapsar. Gerçek ElevenLabs sesi API anahtarı sağlanmadan üretilmiş veya hesapta doğrulanmış sayılmaz. Windows DPAPI ve fiziksel hoparlör bu Linux bulut ortamında doğrulanmadı.

## V32.5: yüklenen kayıtla yerel referans ses

Varsayılan Windows başlatıcı artık referans kayıtla yerel XTTS-v2 sesini seçer; ElevenLabs API anahtarı istemez. WHISPER_BASLAT.cmd ilk açılışta bilgisayarınızdaki orijinal MP3/WAV kaydını seçtirir. Ana Python ortamına Torch/TTS kurulmaz: LOCALAPPDATA/WhisperAstra/reference/venv altında ayrı bir ses ortamı hazırlanır. Model yaklaşık 1,9 GB’dır; çalışma paketleri ayrıca indirilir. Uyumlu NVIDIA sürücüsü (560+) algılanırsa CUDA 12.6 Torch paketi, aksi durumda CPU paketi kurulur. Model ağırlıkları sabit upstream sürüm ve SHA256 ile doğrulanır. Bu ilk kurulum zaman alabilir; yarım indirmede doğru tamamlanmış dosyalar korunur.

Seçtiğiniz kaydın ilk uygun konuşma bölümünden en fazla 20 saniyelik mono 24 kHz referans üretilir. Referans ve orijinal dosya yolu yalnız yerel kullanıcı klasöründe saklanır; GitHub güncelleme paketine eklenmez. WHISPER_SES_KAYDI.cmd başka bir kayıt seçtirir. Windows’ta yerel dosya seçme işlemini kullanıcı yapar; bulut masaüstünüzü doğrudan okuyamaz.

Ses modeli ayrı, kalıcı bir işçi süreçte yüklenir ve konuşmacı koşullaması bir kez hesaplanır. CUDA mevcut ve en az 2,8 GB boş GPU belleği varsa GPU denenir; bellek hatasında CPU’ya döner. Modelin/STT/LLM’nin toplam GPU kullanımı bilgisayarda ayrıca ölçülmelidir. CPU yavaş olabilir: bulut denemesinde 5,47 saniyelik sesi üretmek 51,18 saniye sürdü. Bu CPU sonucu canlı sohbet hızı değildir; GPU performansı henüz doğrulanmadı. Referans kayıt orijinal ElevenLabs modeliyle aynı kaliteyi veya birebir sesi garanti etmez.

Ses üretiminde internet/API çağrısı yapılmaz. Aynı kısa metin sınırlı RAM önbelleğinden tekrar çalınabilir. İptal sırasında üretim süreci sonlandırılır; sonraki yeni üretimde model tekrar yüklenebilir. Oynatma küçük ses bloklarında iptal edilir. Kapanışta işçi kapatılır, geçici üretilmiş WAV dosyaları temizlenir. Ayrıntılı hata günlüğü yerel reference/worker.log dosyasındadır.

ElevenLabs API seçeneği korunur: whisper_bootstrap.py --elevenlabs ile önceki API modu açılır. Varsayılan referans modunda ücretli ElevenLabs isteği yapılmaz. Model Coqui Public Model License kapsamındadır; lisans ve kaynak bilgisi XTTS_MODEL_LICENSE.txt dosyasındadır.

V32.5 doğrulama: 453 otomatik test geçti. Gerçek yüklenen MP3 kaydı SDK ortamında açılıp mono 24 kHz WAV referansa dönüştürüldü. Gerçek ayrı işçiyle 4,13 saniyelik yeni ses 30,86 saniyede üretildi; model ilk açılışı dahil toplam 71,92 saniyeydi. Aynı metnin önbellekten tekrar hazırlanması ölçümde 0,0 saniyeydi. Üretilen WAV biçimi kontrol edildi ve işçi kapanışı doğrulandı; bu denemede fiziksel oynatma çağrısı başlıksız bulut nedeniyle atlandı. Windows/GPU sonucu ve insan tarafından ses benzerliği değerlendirmesi henüz doğrulanmadı.
