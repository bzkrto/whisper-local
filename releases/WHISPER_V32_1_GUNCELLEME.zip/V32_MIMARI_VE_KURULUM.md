# Whisper V32 — sohbet ve test edilen otomatik kod geliştirme

Bu sürüm yüklenen V31 dosyaları üzerine geliştirilmiştir. Whisper_OS_Mimari_Tasarim.pdf bir vizyon belgesidir; aşağıdaki tablo uygulanan parçaları ve gelecekte yapılacak işleri ayırır.

| Mimari parçası | V32'deki karşılığı |
| --- | --- |
| Core Brain / doğal sohbet | Aynı komut işleyicisi ses ve yazıyı karşılar; son sekiz konuşma turu bağlama girer. GUI'de Sohbet ve İşlem günlüğü ayrı sekmelerdir. |
| AI Router | chat, code, reason, vision ve fast rolleri; kurulu Ollama modelleri ve ayrı rol sunucuları. PDF'deki DeepSeek/Gemma adları zorunlu değildir. |
| Kalıcı hafıza | Kullanıcı beyanları, geçmiş konuşma, belge/kaynak kayıtları, deneyimler ve kaynaklı bilgi kartları. Gerçek anlamsal embedding veya bilgi grafiği bu güncellemede eklenmedi. |
| Learning / kod geliştirme | Kaynaklı gelişim taslağı veya açık kullanıcı hedefi -> ayrı kod taslağı -> Docker testleri -> yedekli kaynak ve sürüm bildirimi güncellemesi. |
| Ses / Türkçe | Microsoft EmelNeural, normal hız; yerel Whisper; kalıcı kullanıcı terim sözlüğü; bağlamdaki tek kelimelik yanıtlar korunur. |
| Computer Control | Mevcut izinli araçlar, uygulama envanteri, ekran ve dosya işlemleri korunur. |
| Rapor / sunum / video | Mevcut Word/PDF/PowerPoint ve senaryo akışı korunur. Otomatik video render eklenmedi. |
| Security / Behavior / Order | Mevcut araç doğrulama ve hatırlatmalar korunur. Antivirüs, hesap güvenliği denetimi, alışkanlık çıkarımı veya satın alma ajanı eklenmedi. |

## Bilgisayarda kurulum

1. Whisper'ı kapatın. Mevcut whisper astra klasörünün yedeğini alın.
2. WHISPER_V32_GUNCELLEME.zip içeriğini mevcut proje klasörüne çıkarın; aynı adlı kod dosyalarını güncelleyin.
3. Paket kişisel veritabanını, mikrofon profilini, ses referanslarını, .venv ortamını veya modelleri içermez; bunları koruyun.
4. Ollama'yı açın. Mevcut qwen3:8b sohbet ve qwen2.5-coder:7b kod modeli kullanılır. Görsel model yalnız ekran isteğinde gereklidir.
5. Kod geliştirmede kullanılacak test imajını WHISPER_TEST_ORTAMI.cmd ile hazırlayın. Docker Desktop açık olmalıdır. İmaj hazırlanmamışsa kod güncellemesi uygulanmaz; durum günlüğünde görünür.
6. WHISPER_KONTROL.cmd ile paket kontrolünü, WHISPER_BASLAT.cmd ile uygulamayı açın.

## Karşılıklı konuşma

İlk komutta “Hey Whisper” deyin. Yanıt tamamlandıktan sonraki 20 saniye boyunca tekrar seslenmeden konuşabilirsiniz. Modelin yanıt üretme ve seslendirme süresi bu pencereyi tüketmez. “Sohbeti bitir”, “Dinlemeyi bitir” veya “Şimdilik bu kadar” bu pencereyi kapatır. “Dur / sus” yanıtı keser; “çıkış” uygulamayı kapatır.

İsterseniz CLI'de --single-turn ile her komut için tekrar seslenme davranışını seçebilirsiniz. --conversation-timeout 5–120 saniye aralığında ayarlanabilir. Mikrofon düğmesi ses girişini kapatır.

Genel bilgi soruları, “nedir / kaç” sözcükleri yüzünden internet kapalıyken engellenmez. Güncel fiyat/haber/hava gibi gerçekten dış kaynağa ihtiyaç duyan sorularda mevcut doğrulama akışı korunur. Kısa isim/uygulama yanıtları bir açıklama sorusuna cevap olduğunda rastgele kelime sayılıp atılmaz.

## Ses ve kelimeler

Windows başlatıcısı artık Microsoft EmelNeural ve normal hız kullanır. Önceki başlatıcıdaki AhmetNeural de Microsoft hizmetiydi; Google TTS kullanılmıyordu. İlk V32 açılışı yeni tercihi kaydeder; sonraki kullanıcı seçimleri korunur. “Ahmet sesini kullan”, “Emel sesini kullan”, “Normal hızda konuş” gibi komutlar kullanılabilir.

“Kelime öğret: Bergen” veya “Kelime öğret: bütçe raporu” terimi yerel ses sözlüğüne kaydeder. “Ses sözlüğü” kayıtları gösterir. Bu terimler sonraki Whisper tanımalarında ipucu olur; duyulmayan bir cümle yerine komut yazılmaz ve model ağırlıkları eğitilmez.

Edge hizmeti erişilemezse yalnız kurulu Türkçe Windows sesi yedek olarak kullanılır. Türkçe yerel ses yoksa İngilizce bir sesle yanlış telaffuz edilmez; metin yanıtı korunur. Windows oynatma ve fiziksel mikrofon/GPU doğruluğu bilgisayarınızda ayrıca kontrol edilmelidir.

## Kendi kodunu geliştirme

- “Kendini geliştir: Türkçe kısa yanıtların önceki soruya bağlanmasını iyileştir” açık bir geliştirme hedefi ekler.
- “Gelişim durumu” veya “Otomatik gelişim durumu” aşamaları gösterir.
- “Otomatik gelişimi durdur / başlat” kalıcı anahtarı değiştirir.
- Kaynaklı bilgi kartlarından üretilen gelişim hedefleri de otomatik sıraya alınır.

Program açıkken zamanlayıcı boşta, tek bir hedef üzerinde çalışır. Her hedef en fazla üç kod denemesi yapar; sonraki denemeye önceki test hatası veri olarak eklenir. İşlem aralığı en az on dakikadır. Öndeki kullanıcı komutu için ayrılan kilit ve iptal denetimleri korunur.

Her taslak en fazla iki küçük mevcut Python modülünü değiştirir; güncelleyici, izin kontrolleri, testler ve bağımlılıklar model tarafından değiştirilmez. Kod, ağ ve kişisel veriler bulunmayan, kaynak kopyası salt okunur Docker ortamında test edilir. Sıfır test çalışması başarı kabul edilmez. Başarısız veya iptal edilen taslak canlı koda yazılmaz. Test edilen içerik veya canlı kaynak arada değişirse uygulama durdurulur.

Başarılı güncellemede değişen dosyalar ve WHISPER_SURUM.json yedeklenir; dosyalar geçici dosya üzerinden değiştirilir, sürüm bildirimi en son yazılır. Normal yazma hatasında değişen dosyalar geri alınır. Güncelleme kilidi sırasında ikinci güncelleme ve yeni bootstrap açılışı engellenir. Güncellenen kod bir sonraki uygulama açılışında etkinleşir; mevcut Python nesneleri kendiliğinden yeniden yüklenmiş sayılmaz.

Yedekler veritabanı klasöründeki iyilestirme_taslaklari/<taslak>/backup dizinindedir. Süreç veya bilgisayar güncellemenin ortasında zorla kapanırsa kilit kalabilir: işlem artık çalışmıyorsa bu dizindeki yedekleri proje klasörüne geri koyup .whisper-update.lock dosyasını kaldırın. Başlatıcı bütünlük bozukken çalışmayı reddeder.

Bu akış kodu değiştirebilir; her değişikliğin yararlı olduğunu veya genel zekâyı artırdığını garanti etmez. Test kapsamı ve seçilen kod modelinin kalitesi belirleyicidir. Buluttaki küçük kod modeli Türkçe harf düzeltmesinde başarısız taslaklar üretti; testler bunların uygulanmasını engelledi. Model ağırlıkları eğitilmez.

## Bulut doğrulaması

Tüm otomatik testler son doğrulamada ayrıca raporlanır. Gerçek Microsoft Emel sesiyle MP3 üretildi; bu bilinen kısa örnek, gerçek CPU faster-whisper ile sıfır kelime hatasıyla tanındı. Bu ölçüm mikrofonunuzun doğruluk oranı değildir.

Bulut geliştirme için ayrı Qwen sohbet ve Qwen2.5-Coder CPU sunucuları, yerel faster-whisper-small ve izole Docker test imajı hazırlandı. Windows'taki qwen3:8b/qwen2.5-coder:7b modellerinin kalitesi ve GPU performansı bu kontrolün sonucu olarak gösterilmez.

## V32.1 tok erkek ses profili

Kullanıcı isteğiyle varsayılan ses Türkçe destekleyen Microsoft BrianMultilingualNeural erkek sesi olarak değiştirildi. Hız ve ton normaldir (+0%, +0Hz); sesin kendi doğal erkek tınısı kullanılır. İlk V32.1 açılışı bu profili kaydeder, sonraki kullanıcı tercihleri korunur. “Brian sesini kullan” veya “Erkek sesini kullan” bu sesi seçer. “Ahmet sesini kullan” ve “Emel sesini kullan” önceki seçeneklere döner. CLI --voice, --rate ve --pitch açıkça verilirse kayıtlı ayarı geçersiz kılar; ton tercihi de artık kalıcıdır.

Bu güncelleme aynı Microsoft Edge ses hizmetini kullanır; ücretli sağlayıcı veya ses klonlama eklenmemiştir. BrianMultilingualNeural adındaki en-US, ses kimliğinin adıdır; model Türkçe konuşabilir. Türkçe örnek çevrimiçi hizmetle gerçekten üretildi. Ahmet için denenen negatif hız/ton ayarlarında bu ortamda ses alınamadığından bunlar varsayılan yapılmadı. Tokluk ve aksan beğenisi kullanıcı tarafından örnek dinlenerek değerlendirilmelidir.
