"""Local voice runtime helpers."""
