"""WHISPER modular assistant layers."""
