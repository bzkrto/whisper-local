@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Whisper .venv ortami bulunamadi. Bu dosyayi Whisper klasorunden calistirin.
  pause
  exit /b 1
)
echo Whisper kapali olmali. Edge TTS yalniz bu projenin ortaminda guncellenecek.
".venv\Scripts\python.exe" -m pip install --upgrade edge-tts pyttsx3
if errorlevel 1 (
  echo Guncelleme basarisiz. Internet baglantisini kontrol edin. V29 yerel ses yedegini yine deneyebilir.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip show edge-tts pyttsx3
echo Guncelleme tamamlandi. WHISPER_BASLAT.cmd ile acin.
echo Bu islem Windows guvenlik ayarlarini degistirmez.
pause
