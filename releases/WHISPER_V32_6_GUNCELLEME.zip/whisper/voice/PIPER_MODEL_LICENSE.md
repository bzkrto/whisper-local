# Türkçe yerel ses modeli

Model: rhasspy/piper-voices, tr_TR-dfki-medium.
Sabit kaynak sürümü: c10ece1aade47bb51c153c893d14e5bf8e5b7117.
Model kartı: https://huggingface.co/rhasspy/piper-voices/blob/c10ece1aade47bb51c153c893d14e5bf8e5b7117/tr/tr_TR/dfki/medium/MODEL_CARD
Veri kaynağı: https://github.com/marytts/dfki-ot-data/
Model kartında belirtilen veri lisansı: CC BY-NC-SA 4.0 — https://creativecommons.org/licenses/by-nc-sa/4.0/
Bu ses profili kişisel, ticari olmayan kullanım için seçilmiştir. Ticari dağıtım için lisans şartları ayrıca değerlendirilmelidir.
Piper yazılımı: https://github.com/OHF-Voice/piper1-gpl (GPL-3.0).
Ses modeli indirilir; kod paketi model ağırlıklarını içermez.
